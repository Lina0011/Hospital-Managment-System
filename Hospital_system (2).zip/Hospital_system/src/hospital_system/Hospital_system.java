
package hospital_system;

import javax.swing.JFrame;

public class Hospital_system {

   
    public static void main(String[] args) {
        
        JFrame SFrame = new start();
        SFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        SFrame.setSize(1098, 670);
        SFrame.setVisible(true);
    }
    
}
