/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital_system;

import java.util.Date;

/**
 *
 * @author Le99L
 */
class appo {
     private int Id_appointment;
    private String name,clinic;
    private Date date;
    

    public appo(int Id_appointment, Date date, String name, String clinic) {
        this.Id_appointment = Id_appointment;
        this.date = date;
        this.name = name;
        this.clinic = clinic;
    }

    public int getId_appointment() {
        return Id_appointment;
    }

    public Date getDate() {
        return date;
    }

    public String getName() {
        return name;
    }

    public String getClinic() {
        return clinic;
    }
    
   
}
