/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital_system;

/**
 *
 * @author Le99L
 */
class patient {
    private int ID,age,phone;
    private String name,gender,address;

    public int getID() {
        return ID;
    }

    public int getAge() {
        return age;
    }

    public int getPhone() {
        return phone;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public String getAddress() {
        return address;
    }
   
    public patient(int ID, String name,int age,String gender, int phone, String address) {
        this.ID = ID;
        this.age = age;
        this.phone = phone;
        this.name = name;
        this.gender = gender;
        this.address = address;
    }
    
}
